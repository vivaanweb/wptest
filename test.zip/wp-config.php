<?php
define('WP_AUTO_UPDATE_CORE', false);// This setting was defined by WordPress Toolkit to prevent WordPress auto-updates. Do not change it to avoid conflicts with the WordPress Toolkit auto-updates feature.
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wordpress_test');

/** MySQL database username */
define('DB_USER', 'wordpress_test');

/** MySQL database password */
define('DB_PASSWORD', 'Maddybm@369');

/** MySQL hostname */
define('DB_HOST', 'localhost:3306');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY', '3l~Cp8tG2)k4J0tRb&9XNfS|7/4!~_!&7_*JcpJJ(8Wx+h86*+8bTT)h@u0aSsV(');
define('SECURE_AUTH_KEY', '9m8kM991C2;pQ3l!R4kCd(V_Vp%E6X0J0teV48a;9l-~Y-i9m2wEJ2#+a_kGux(C');
define('LOGGED_IN_KEY', 'v51vSu4(L45(8h:1;~3d6ug&0W:1O]7MUj9lgeoV#Pvv*VgtKNYp0r*j3v!T[%eT');
define('NONCE_KEY', '8kyy%3---|n|n-7L9[682VKCZ_]1KH-D3Mm-3Ls3Kcaf~71v+[@-L3X7vb+3Ds4/');
define('AUTH_SALT', '0N-J(awe@X4&l)+4)Pz9q9WW((k73/p/8b010THYG5Dn8O#Da1mT8+F#*+ap78pJ');
define('SECURE_AUTH_SALT', 'q[9h@nTCN4|K16~Jg2D*GA;Ch+69~5W;xg:49G|To]Re99)w4fXMRxZwlTO9lJ])');
define('LOGGED_IN_SALT', ')%5*qw5FMzEtn1hOD7fdS]/OiN2!;24tNpSzJe@21B6#1O3x1V&I%@#K01pwl6c]');
define('NONCE_SALT', 'WIK~gW562sPffO;TBvoD5PS1LjLSuo5~/rA1!!_0v4[1#cn0XB/63828RUq99-zE');
/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'test_wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');

define( 'WP_ALLOW_MULTISITE', true );

define ('FS_METHOD', 'direct');
